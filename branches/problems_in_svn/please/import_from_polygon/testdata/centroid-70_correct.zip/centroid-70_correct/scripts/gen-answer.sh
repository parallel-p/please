if [ "$1" = "" ]; then
    read
fi
if [ "$2" = "" ]; then
    read
fi
if [ ! -f "$1" ]; then
    read
fi
echo "Running validator"
wine files/towin.exe "$1" | wine files/validator_strict.exe
if [ "$?" -ne "0" ]; then
    read
fi
echo "Running solution centroid_kp.cpp"
wine solutions/centroid_kp.exe < $1 > output.txt
if [ "$?" -ne "0" ]; then
    echo "Solution returned non-zero exit code"
    read
fi
if [ ! -f "output.txt" ]; then
    echo "Solution didn't produced output"
    read
fi
mv output.txt "$2"
echo "Running checker"
wine check.exe $1 $2 $2
if [ "$?" -ne "0" ]; then
    echo "Checker returned non-zero exit code"
    read
fi
