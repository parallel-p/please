#include <iostream>
#include <cassert>
#include <ctime>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <cstdio>
using namespace std;

typedef long long llong;

const int N = 100500;

#ifdef _WIN32_ 
	#define LD "I64d"
#else
	#ifdef __WIN32__
		#define LD "I64d"
	#else
		#define LD "lld"
	#endif
#endif
struct vt
{
	llong x, y;
	vt(){}
	friend llong operator ^(vt a, vt b)
	{
		return a.x * b.y - b.x * a.y;
	}
	friend llong operator *(vt a, vt b)
	{
		return a.x * b.x + a.y * b.y;
	}
	vt (llong _x, llong _y) : x(_x), y(_y)
	{}
	
	friend vt operator -(vt a, vt b)
	{
		return vt(a.x - b.x, a.y - b.y);
	}
	friend vt operator +(vt a, vt b)
	{
		return vt(a.x + b.x, a.y + b.y);
	}
	friend bool operator ==(vt a, vt b)
	{
		return (a - b) * (b - a) == 0;
	}
};

double angle(vt a, vt b)
{
	return atan2(a ^ b, a * b);
}

bool left(vt a, vt b)
{
	if (a * a == 0 || b * b == 0)
		return false;
	return (a ^ b) > 0;
}

void die(string s)
{
	cout << s;
	exit(3);
}

struct poly
{
	int n;
	vt V[3*N];
	void read()
	{
		scanf("%d", &n);
		int x, y;
		for (int i = 0; i < n; i++)
			scanf("%"LD" %"LD"\n", &V[i].x, &V[i].y);
	}
	vt& operator [](int i)
	{
		return V[i % n];
	}
	poly(){}
	llong mny, mxy, div;
	llong mxyl, mxyr, mnyl, mnyr;
	void prepare_to_ans()
	{
		mny = 1e18, mxy = -1e18, div;
		mxyl = 1e18, mxyr = -1e18, mnyl = 1e18, mnyr = -1e18;
		for (int i = 0; i < n; i++)
		{
			if (V[i].y > mxy)
			{
				mxy = V[i].y, div = i;
				mxyl = mxyr = V[i].x;
			}
			else if (V[i].y == mxy)
			{
				mxyl = min(mxyl, V[i].x);
				mxyr = max(mxyr, V[i].x);
			}
			
			if (V[i].y < mny)
			{
				mny = V[i].y, div = i;
				mnyl = mnyr = V[i].x;
			}
			else if (V[i].y == mny)
			{
				mnyl = min(mnyl, V[i].x);
				mnyr = max(mnyr, V[i].x);
			}
		}
	}
	
	int check(vt a, vt b, vt v)
	{
		if (a.y > b.y)
			swap(a, b);
		if (v.y > b.y || v.y < a.y)
			return 10;
		if (a.y == b.y)
		{
			if (a.x > b.x)
				swap(a, b);
			if (v.x < a.x)
				return 1;
			else if (v.x > b.x)
				return -1;
			else
				return 0;
		}
		else if (left(v - b, b - a))
			return -1;
		else if (left(b - a, v - b))
			return 1;
		else
			return 0;
	}
	
	bool in(vt v)
	{
		if (v.y > mxy || v.y < mny)
			return false;
		if (v.y == mxy)
			return mxyl <= v.x && v.x <= mxyr;
		if (v.y == mny)
			return mnyl <= v.x && v.x <= mnyr;
		int a1 = 0, b1 = div;
		int m1;
		while (b1 - a1 > 1)
		{
			m1 = (a1 + b1) / 2;
			if (V[m1].y >= v.y)
				b1 = m1;
			else
				a1 = m1;
		}
		int u1 = check(V[a1], V[b1], v);
		
		int a2 = div, b2 = n;
		int m2;
		while (b2 - a2 > 1)
		{
			m2 = (a2 + b2) / 2;
			if (V[m2].y <= v.y)
				b2 = m2;
			else
				a2 = m2;
		}
		int u2 = check(V[a2], V[b2], v);
		if (u1 == 0 || u2 == 0 || u1 == 1 && u2 == -1)
			return true;
		else
			return false;
	}
} P[3], M;

void build_sum(vt* mv)
{
	int pt[3] = {0, 0, 0};
	llong mny[3] = {(llong)1e18, (llong)1e18, (llong)1e18};
	llong mnx[3] = {(llong)1e18, (llong)1e18, (llong)1e18};
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < P[i].n; j++)
		{
			if (mny[i] > P[i][j].y)
				mny[i] = P[i][j].y, mnx[i] = P[i][j].x, pt[i] = j;
			else if (mny[i] == P[i][j].y)
				if (mnx[i] > P[i][j].x)
					mny[i] = P[i][j].y, mnx[i] = P[i][j].x, pt[i] = j;
		}
	}
	int it[3] = {0, 0, 0};
	vt curv;
	int mvpt = 0;
	mv[mvpt++] = (P[0][pt[0]] + P[1][pt[1]] + P[2][pt[2]]);
	while(1)
	{
		for (int i = 0; i < 3; i++)
			if (it[i] < P[i].n)
				goto good;
		break;
		good:;
		vt mx;
		int mxi;
		bool flag;
		flag = 0;
		for (int i = 0; i < 3; i++)
			if (it[i] < P[i].n)
			{
				if (flag)
				{
					if (left(P[i][pt[i] + 1] - P[i][pt[i]], mx))
						mxi = i, mx = P[i][pt[i] + 1] - P[i][pt[i]];
				}
				else
					mx = P[i][pt[i] + 1] - P[i][pt[i]], mxi = i, flag = 1;
			}
		mv[mvpt] = (mv[mvpt - 1] + mx);
		mvpt++;
		pt[mxi]++;
		it[mxi]++;
		//cerr << mxi << ' ' << mx.x << ' ' << mx.y << endl;
	}	
	assert(mv[mvpt - 1] == mv[0]);
	mvpt--;
}

void debug_sum()
{
	return;
	for (int i = 0; i < M.n; i++)
		cerr << M[i].x << ' ' << M[i].y << endl;
}

int main(int argc, char **argv)
{
#ifdef TASK
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	cerr << clock() << endl;
	for (int i = 0; i < 3; i++)
		P[i].read();
	cerr << clock() << endl;
	build_sum(M.V);
	cerr << clock() << endl;
	M.n = P[0].n + P[1].n + P[2].n;
	cerr << clock() << endl;
	debug_sum();
	cerr << clock() << endl;
	int m;
	cin >> m;
	vt v;
	cerr << clock() << endl;
	M.prepare_to_ans();
	cerr << clock() << endl;
	for (int i = 0; i < m; i++)
	{
		cin >> v.x >> v.y;
		v = v + v + v;
		if (M.in(v))
			cout << "YES";
		else
			cout << "NO";
		cout << endl;
	}
	return 0;
}

