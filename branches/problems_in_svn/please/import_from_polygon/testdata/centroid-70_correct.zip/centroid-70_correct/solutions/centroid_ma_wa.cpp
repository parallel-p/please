#include <iostream>
#include <cassert>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <cstdio>
using namespace std;

typedef long long llong;

struct vt
{
	llong x, y;
	vt(){}
	friend llong operator ^(vt a, vt b)
	{
		return a.x * b.y - b.x * a.y;
	}
	friend llong operator *(vt a, vt b)
	{
		return a.x * b.x + a.y * b.y;
	}
	vt (llong _x, llong _y) : x(_x), y(_y)
	{}
	
	friend vt operator -(vt a, vt b)
	{
		return vt(a.x - b.x, a.y - b.y);
	}
	friend vt operator +(vt a, vt b)
	{
		return vt(a.x + b.x, a.y + b.y);
	}
	friend bool operator ==(vt a, vt b)
	{
		return (a - b) * (b - a) == 0;
	}
};

double angle(vt a, vt b)
{
	return atan2(a ^ b, a * b);
}

bool left(vt a, vt b)
{
	if (a * a == 0 || b * b == 0)
		return false;
	else if ((a ^ b) != 0)
		return (a ^ b) > 0;
	else
		return a * b > 0;
}

void die(string s)
{
	cout << s;
	exit(3);
}

struct poly
{
	int n;
	vector<vt> V;
	void read()
	{
		cin >> n;
		V.resize(n);
		int x, y;
		for (int i = 0; i < n; i++)
			cin >> V[i].x >> V[i].y;
	}
	vt& operator [](int i)
	{
		return V.at(i % V.size());
	}
	void duplicate()
	{
		V.resize(2 * n);
		for (int i = n; i < 2 * n; i++)
			V[i] = V[i - n];
	}
	poly(vector<vt> v)
	{
		V = v;
		n = V.size();
	}
	poly(){}
	llong mny, mxy, div;
	void prepare_to_ans()
	{
		mxy = (llong)(-1e18);
		for (int i = 0; i < V.size(); i++)
		{
			if (V[i].y > mxy)
				mxy = V[i].y, div = i;
		}
		mny = V[0].y;
		duplicate();
	}
	
	int check(vt a, vt b, vt v)
	{
		if (a.y > b.y)
			swap(a, b);
		if (v.y > b.y || v.y < a.y)
			return 10;
		if (a.y == b.y)
		{
			if (a.x > b.x)
				swap(a, b);
			if (v.x < a.x)
				return 1;
			else if (v.x > b.x)
				return -1;
			else
				return 0;
		}
		else if (left(v - b, b - a))
			return -1;
		else if (left(b - a, v - b))
			return 1;
		else
			return 0;
	}
	
	bool in(vt v)
	{
		if (v.y > mxy || v.y < mny)
			return false;
		int a1 = 0, b1 = div;
		int m1;
		while (b1 - a1 > 1)
		{
			m1 = (a1 + b1) / 2;
			if (V[m1].y >= v.y)
				b1 = m1;
			else
				a1 = m1;
		}
		int u1 = check(V[a1], V[b1], v);
		
		int a2 = div, b2 = n;
		int m2;
		while (b2 - a2 > 1)
		{
			m2 = (a2 + b2) / 2;
			if (V[m2].y <= v.y)
				b2 = m2;
			else
				a2 = m2;
		}
		int u2 = check(V[a2], V[b2], v);
		if (u1 == 0 || u2 == 0 || u1 == 1 && u2 == -1)
			return true;
		else
			return false;
	}
} P[3], M;

vector<vt> build_sum()
{
	for (int i = 0; i < 3; i++)
		P[i].duplicate();
	int pt[3] = {0, 0, 0};
	llong mny[3] = {(llong)1e18, (llong)1e18, (llong)1e18};
	llong mnx[3] = {(llong)1e18, (llong)1e18, (llong)1e18};
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < P[i].n; j++)
		{
			if (mny[i] > P[i][j].y)
				mny[i] = P[i][j].y, mnx[i] = P[i][j].x, pt[i] = j;
			else if (mny[i] == P[i][j].y)
				if (mnx[i] > P[i][j].x)
					mny[i] = P[i][j].y, mnx[i] = P[i][j].x, pt[i] = j;
		}
		for (int j = 0; j < P[i].n; j++)
			P[i][j] = P[i][j + pt[i]];
		pt[i] = 0;
		P[i].V.resize(P[i].n);
	}
	
	vt curv;
	vector<vt> mv;
	mv.push_back(P[0][0] + P[1][0] + P[2][0]);
	while(1)
	{
		for (int i = 0; i < 3; i++)
			if (pt[i] < P[i].n)
				goto good;
		break;
		good:;
		vt mx;
		int mxi;
		bool flag;
		flag = 0;
		for (int i = 0; i < 3; i++)
			if (pt[i] < P[i].n)
			{
				if (flag)
				{
					if (left(P[i][pt[i] + 1] - P[i][pt[i]], mx))
						mxi = i, mx = P[i][pt[i] + 1] - P[i][pt[i]];
				}
				else
					mx = P[i][pt[i] + 1] - P[i][pt[i]], mxi = i, flag = 1;
			}
		mv.push_back(mv[mv.size() - 1] + mx);
		pt[mxi]++;
		//cerr << mxi << ' ' << mx.x << ' ' << mx.y << endl;
	}	
	assert(mv[mv.size() - 1] == mv[0]);
	mv.pop_back();
	return mv;
}

void debug_sum()
{
	//for (int i = 0; i < M.n; i++)
	//	cerr << M[i].x << ' ' << M[i].y << endl;
}

int main(int argc, char **argv)
{
#ifdef TASK
	freopen(TASK".in", "r", stdin);
	freopen(TASK".out", "w", stdout);
#endif
	for (int i = 0; i < 3; i++)
		P[i].read();
	M = poly(build_sum());
	debug_sum();
	int m;
	cin >> m;
	vt v;
	M.prepare_to_ans();
	for (int i = 0; i < m; i++)
	{
		cin >> v.x >> v.y;
		v = v + v + v;
		if (M.in(v))
			cout << "YES";
		else
			cout << "NO";
		cout << endl;
	}
	return 0;
}

