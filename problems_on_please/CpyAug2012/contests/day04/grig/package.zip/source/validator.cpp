#include "testlib.h"

using namespace std;

int main() {
    registerValidation();

    return 0;
}