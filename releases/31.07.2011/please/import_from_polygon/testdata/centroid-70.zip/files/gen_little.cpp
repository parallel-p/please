/*
 * Единственный параметр - сторона квадрата 2A x 2A с центром в начале координат
*/
#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cassert>
#define mp make_pair
#define pb push_back
#define x first
#define y second
 
#include "testlib.h"
 
using namespace std;
 
 
typedef double ld;
typedef long long int64;
typedef pair<int,int> point;
 
 
vector<point> genPoints(int number,int maxc){
        ld r=maxc;
        ld a[2][2];
        for (int i = 0; i < 2; i++)
                for (int j = 0; j < 2; j++)
					a[i][j] = rnd.next(maxc/(4 * r),maxc/(2*r)) * (rnd.next(0,1) * 2 - 1);
        vector<point> result;
        for (int i=0;i<number;i++){
                ld ang = rnd.next(0.0,2*M_PI);
                ld x = r * cos(ang),y = r * sin(ang);
                ld x1 = x * a[0][0] + y * a[0][1];  
                ld y1 = x * a[1][0] + y * a[1][1];
                result.pb(mp(int(x1+0.5),int(y1+0.5)));
        }       
        return result;
}
 
 
bool cmp(const point& a,const point& b){
        int64 tmp = a.x * 1LL * b.y - a.y * 1LL * b.x;
        if (tmp == 0)
                return a.x*1LL*a.x + a.y*1LL*a.y < b.x * 1LL * b.x + b.y * 1LL * a.y;  
        return tmp > 0;
}
 
bool good(const point& a,const point& b,const point& c){
        return (b.x - a.x) * 1LL * (c.y - a.y) - (c.x - a.x) * 1LL* (b.y - a.y) > 0;
}
 
void convex(vector<point>& a){
        sort(a.begin(),a.end());
        a.erase(unique(a.begin(),a.end()),a.end());
        int n=a.size();
        vector<point> b;
        for (int i=0;i<n;i++)
                if (a[i].y < a[n-1].y || (a[i].y == a[n-1].y && a[i].x < a[n-1].x))
                        swap(a[i],a[n-1]);
        point sdv = a[n-1];
        a.pop_back();
        --n;
        for (int i = 0; i < n; i++){
                a[i].x -= sdv.x;
                a[i].y -= sdv.y;
                assert(a[i].y >= 0);
        }
        b.pb(mp(0,0));
        sort(a.begin(),a.end(),cmp);
        for (int i = 0; i < n; i++){
                for (;b.size() > 1 && !good(b[b.size()-2],b[b.size()-1],a[i]);b.pop_back());
                b.pb(a[i]);
        }       
        for (int i = 0; i < b.size(); i++){
                b[i].x += sdv.x;
                b[i].y += sdv.y;
        }
        a=b;
}
 
void printconvex(int number,int maxc){
        while (true){
                vector<point> poly = genPoints(number*10,maxc);
                convex(poly);
                //cerr << poly.size() << endl;
                if (poly.size() < number)
                        continue;
                vector<int> use(poly.size());
                for (int i = 0 ; i < (int)use.size(); i++)
                        use[i] = i;
                shuffle(use.begin(),use.end());
                sort(use.begin(),use.begin()+number);
                vector<point> poly2(number);
                for (int i=0;i<number;i++)
                        poly2[i]=poly[use[i]];
                rotate(poly2.begin(),poly2.begin()+rnd.next(0,number-1),poly2.end());
                printf("%d\n",number);
                for (int i=0;i<number;i++)
                        printf("%d %d\n",poly2[i].x,poly2[i].y);
                printf("\n");
                break;
        }
}
 
 
 
int main(int argc,char** argv){
        registerGen(argc,argv);
        int mx=atoi(argv[1]);
        int m=(2 * mx + 1) * (2 * mx + 1);
        printconvex(mx / 2,mx);
        printconvex(mx / 2,mx);
        printconvex(mx / 2,mx);
        
        printf("%d\n",m);
        for (int x = -mx; x <= mx; x++)
			for (int y = -mx; y <= mx; y++)
                printf("%d %d\n",x, y);
        return 0;       
}
