/* Проверяет: 
 * корректность формата входных данных
 * многоугольники на левозакрученность
 * многоугольники на многоугольность =)
 * 
 * Zlobober (makhmedov)
 */

#include <vector>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include "testlib.h"
using namespace std;

typedef long long llong;

const int N = 50000;
const int M = 100000;
const int C = 500000000;

struct vt
{
	llong x, y;
	vt(){}
	friend llong operator ^(vt a, vt b)
	{
		return a.x * b.y - b.x * a.y;
	}
	friend llong operator *(vt a, vt b)
	{
		return a.x * b.x + a.y * b.y;
	}
	vt (llong _x, llong _y) : x(_x), y(_y)
	{}
	
	friend vt operator -(vt a, vt b)
	{
		return vt(a.x - b.x, a.y - b.y);
	}
};

vt readVt(int num, int i)
{
	int x, y;
	x = inf.readInt(-C, C, "x[" + vtos(num) + "][" + vtos(i + 1) + "]"); 
	inf.readSpace();
	y = inf.readInt(-C, C, "y[" + vtos(num) + "][" + vtos(i + 1) + "]"); 
	inf.readEoln();
	return vt(x, y);
}

double angle(vt a, vt b)
{
	return atan2(a ^ b, a * b);
}

vt readVt(int i)
{
	int x, y;
	x = inf.readInt(-C, C, "x[" + vtos(i + 1) + "]"); 
	inf.readSpace();
	y = inf.readInt(-C, C, "x[" + vtos(i + 1) + "]"); 
	inf.readEoln();
	return vt(x, y);
}

bool left(vt a, vt b)
{
	if (a * a == 0 || b * b == 0)
		return false;
	else if ((a ^ b) != 0)
		return (a ^ b) > 0;
	else
		return a * b > 0;
}

void die(string s)
{
	cout << s;
	exit(3);
}

struct poly
{
	vector<vt> V;
	int num;
	poly(int _num) : num(_num)
	{
		read();
		check();
	}
	void check()
	{
		int n = V.size();
		for (int i = 0; i < V.size(); i++)
			if (!left(V[(i + 1) % n] - V[(i + 0) % n], V[(i + 2) % n] - V[(i + 1) % n]))
				quitf(_fail, "%d polygon is not convex or is clockwise-rotated (%lld %lld),(%lld %lld) (%lld %lld)",num,V[(i)%n].x,V[(i)%n].y,V[(i+1)%n].x,V[(i+1)%n].y,V[(i+2)%n].x,V[(i+2)%n].y);

		double rot = 0;
		for (int i = 0; i < V.size(); i++)
			rot += angle(V[(i + 1) % n] - V[(i + 0) % n], V[(i + 2) % n] - V[(i + 1) % n]);
		if (fabs(rot - 2 * M_PI) >= M_PI)
			quitf(_fail, "%d is not a polygon");
	}
	void read()
	{
		int n = inf.readInt(3, N, "n");
		inf.readEoln();
		V.resize(n);
		int x, y;
		for (int i = 0; i < n; i++)
			V[i] = readVt(num, i);
		inf.readEoln();
	}
	poly(){}
};

int main()
{
    registerValidation();
    
    poly P[3];
    
	for (int i = 0; i < 3; i++)
		P[i] = poly(i);
    
    int m = inf.readInt(0, M, "m");
    inf.readEoln();
    vt v;
    
    for (int i = 0; i < m; i++)
        v = readVt(i);

    inf.readEof();
    return 0;
}
