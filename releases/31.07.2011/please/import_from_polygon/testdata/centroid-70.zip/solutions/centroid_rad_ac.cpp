#define _CRT_SECURE_NO_DEPRECATE

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <iostream>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <cctype>
#include <sstream>
#include <cassert>
#include <bitset>
#include <memory.h>

using namespace std;

#pragma comment(linker, "/STACK:200000000")

typedef long long int64;

#define forn(i, n) for(int i = 0; i < (int)(n); i++)
#define ford(i, n) for(int i = (int)(n) - 1; i >= 0; i--)
#define fore(i, a, n) for(int i = (int)(a); i < (int)(n); i++)
#define pb push_back
#define mp make_pair
#define fs first
#define sc second
#define last(a) (int(a.size()) - 1)
#define all(a) a.begin(), a.end()

const long double EPS = 1E-15;
const int INF = 1000000000;
const int64 INF64 = (int64) 1E18;
const long double PI = 3.1415926535897932384626433832795;

int n;

struct pt {
	int64 x, y;

	pt() {}
	pt(int64 x, int64 y): x(x), y(y) {}

	bool operator< (const pt &a) const {
		return mp(x, y) < mp(a.x, a.y);
	}

	bool operator== (const pt &a) const {
		return mp(x, y) == mp(a.x, a.y);
	}

	long double ang() {
		double res = PI / 2 + atan2((long double)y, (long double)x);
		while (res < EPS)
			res += 2 * PI;
		return res;
	}
};

inline pt operator+ (const pt &a, const pt &b) {
	return pt(a.x + b.x, a.y + b.y);
}

inline pt operator- (const pt &a, const pt &b) {
	return pt(a.x - b.x, a.y - b.y);
}

void read(vector<pt> &a) {
	int n;
	cin >> n;
	a.resize(n);
	forn(i, n)
		scanf("%I64d%I64d", &a[i].x, &a[i].y);
}

void sum(vector<pt> &a, vector<pt> b) {
	rotate(a.begin(), min_element(all(a)), a.end());
	rotate(b.begin(), min_element(all(b)), b.end());

	vector<pt> c;
	c.pb(a[0] + b[0]);

	vector<pair<long double, pt> > v;
	forn(i, a.size()) {
		pt p = a[(i + 1) % int(a.size())] - a[i];
		v.pb(mp(p.ang(), p));
	}
	forn(i, b.size()) {
		pt p = b[(i + 1) % int(b.size())] - b[i];
		v.pb(mp(p.ang(), p));
	}

	sort(all(v));

	forn(i, v.size()) {
		pt ne = c.back() + v[i].sc;
		c.pb(ne);
	}
	c.pop_back();

	a = c;
}

inline int sign(int64 a) {
	return a < 0 ? -1 : a == 0 ? 0 : +1;
}

inline int sign(pt a, pt b, pt m) {
	if (b.x < a.x)
		throw;

	return sign((m.y - a.y) * (b.x - a.x) - (m.x - a.x) * (b.y - a.y));
}

inline int sign(vector<pt> &a, pt b) {
	if (b < a[0] || a.back() < b)
		return 1;
	if (b == a[0] || a.back() == b)
		return 0;
	int p = int(lower_bound(all(a), b) - a.begin());
	return sign(a[p - 1], a[p], b);
}

vector<pt> a, b, c, up, down;

int main() {
#ifdef RADs_project
    freopen("input.txt", "rt", stdin);
    freopen("output.txt", "wt", stdout);
#endif	
	
	read(a);
	read(b);
	read(c);

	sum(a, b);
	sum(a, c);

//	reverse(all(a));

	n = (int)a.size();

	rotate(a.begin(), min_element(all(a)), a.end());

	int mpos = int(max_element(all(a)) - a.begin());

	forn(i, mpos + 1)
		down.pb(a[i]);
	fore(i, mpos, n)
		up.pb(a[i]);
	up.pb(a[0]);
	reverse(all(up));

	int q;
	cin >> q;
	forn(i, q) {
		pt p;
		cin >> p.x >> p.y;
		p.x *= 3;
		p.y *= 3;

		puts(sign(down, p) >= 0 && sign(up, p) <= 0 ? "YES" : "NO");
	}
	
	return 0;
}