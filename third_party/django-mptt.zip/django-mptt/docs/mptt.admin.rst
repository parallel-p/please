==============
``mptt.admin``
==============

.. automodule:: mptt.admin
    :members:
    :undoc-members:
