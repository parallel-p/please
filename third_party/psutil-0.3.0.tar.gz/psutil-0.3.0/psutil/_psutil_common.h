/*
 * $Id: _psutil_common.h 831 2010-11-20 21:53:59Z g.rodola $
 */

#include <Python.h>

PyObject* NoSuchProcess(void);
PyObject* AccessDenied(void);

